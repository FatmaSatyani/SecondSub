package com.fatmasatyani.githubuser2

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import com.bumptech.glide.Glide
import com.bumptech.glide.load.engine.DiskCacheStrategy
import com.bumptech.glide.request.RequestOptions
import com.fatmasatyani.githubuser2.databinding.ActivityDetailBinding
import com.fatmasatyani.githubuser2.databinding.ActivityMainBinding
import com.loopj.android.http.AsyncHttpClient
import com.loopj.android.http.AsyncHttpResponseHandler
import cz.msebera.android.httpclient.Header
import org.json.JSONObject

class DetailActivity : AppCompatActivity() {

    private lateinit var binding: ActivityDetailBinding
    private lateinit var adapter: GithubAdapter
    private val TAG = "DetailActivity"

    companion object {
        const val EXTRA_GITHUB = "extra_github"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val dataGithub: Github? = intent.getParcelableExtra(EXTRA_GITHUB)
        val username = "${dataGithub?.username}"
//            getUser(username)

        binding.apply {
            Glide.with(this@DetailActivity)
                .load(dataGithub?.avatar)
                .diskCacheStrategy(DiskCacheStrategy.NONE)
                .apply(RequestOptions().override(460,460))
                .into(imgUserPhoto)
            txtUserName.text = "${dataGithub?.name}"
            txtUserId.text = "${dataGithub?.username}"
            txtUserLocation.text = "${dataGithub?.location}"
            txtUserCompany.text = "${dataGithub?.company}"
            txtUserRepository.text = "${dataGithub?.repository}"
            txtUserFollower.text = "${dataGithub?.followers}"
            txtUserFollowing.text = "${dataGithub?.following}"
        }
        Log.d(TAG, "${dataGithub?.location}")
    }

    private fun getUser (username: String?) {
        binding.progressBar.visibility = View.VISIBLE
        val listItems = ArrayList<Github>()
        val user = AsyncHttpClient()
        val url = "https://api.github.com/users/" + username
        user.addHeader("Authorization", "token d482eebf2803d1bcac229b1a250222c5b58f961d")
        user.addHeader("User-Agent", "request")
        user.get(url, object : AsyncHttpResponseHandler() {
            override fun onSuccess(statusCode: Int, headers: Array<out Header>, responseBody: ByteArray) {
                binding.progressBar.visibility = View.INVISIBLE
                try {
                    val result = String (responseBody)
                    val responseObject = JSONObject(result)
                        val name = responseObject.getString("name")
                        val username = responseObject.getString("login")
                        val location = responseObject.getString("location")
                        val company = responseObject.getString("company")
                        val repository = responseObject.getInt("public_repos")
                        val follower = responseObject.getInt("followers")
                        val following = responseObject.getInt("following")
                        val avatar = responseObject.getString("avatar_url")
                        val user = Github()
                        user.name = name
                        user.username = username
                        user.location = location
                        user.company = company
                        user.repository = repository
                        user.followers = follower
                        user.following = following
                        user.avatar = avatar

                        listItems.add(user)

                        adapter.setData(listItems)
                        showLoading(false)
                    } catch (e: Exception) {
                        Toast.makeText(this@DetailActivity, e.message, Toast.LENGTH_SHORT).show()
                        e.printStackTrace()
                }
                Log.d(TAG, "Sukses ${responseBody.toString()} $statusCode")
            }

            override fun onFailure(statusCode: Int, headers: Array<out Header>, responseBody: ByteArray,error: Throwable) {
                binding.progressBar.visibility = View.INVISIBLE

                val errorMessage = when (statusCode) {
                    401 -> "$statusCode : Bad Request"
                    403 -> "$statusCode : Forbidden"
                    404 -> "$statusCode : Not Found"
                    else -> "$statusCode : ${error.message}"
                }
                Log.d(TAG, "Gagal $error ${responseBody.toString()} $statusCode")
                Toast.makeText(this@DetailActivity, errorMessage, Toast.LENGTH_LONG).show()
            }
        })
    }

    private fun showLoading(state: Boolean) {
        if(state) {
            binding.progressBar.visibility = View.VISIBLE
        } else {
            binding.progressBar.visibility = View.GONE
        }
    }
}


